package iborreg.orderchatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderChatbotApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderChatbotApplication.class, args);
    }
}

